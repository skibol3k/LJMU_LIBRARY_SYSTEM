package uk.ac.livjm.cms;

import java.io.File;
import java.io.FileWriter;
import java.io.IOException;

public class Registration
{
  String username;
  String password;
  
  public Registration()
  {
    this.username = "uPlaceholder";
    this.password = "pPlaceholder";
  }
  
  public String getTempUsername()
  {
    return this.username;
  }
  
  public String getTempPassword()
  {
    return this.password;
  }
  
  public void setUsername(String username)
  {
    this.username = username;
  }
  
  public void setPassword(String password)
  {
    this.password = password;
  }
  
  public void writeFile(String username, String password)
		    throws IOException
		  {
		    File Users = new File(TheLibrary.instance.fileURL());
		    FileWriter writer = new FileWriter(Users, true);
		    writer.write(username);
		    writer.write("::");
		    writer.write(password);
		    writer.write("::0\r\n");
		    writer.flush();
		    writer.close();
		  }
}




