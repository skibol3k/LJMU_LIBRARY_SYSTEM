package uk.ac.livjm.cms;

import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.util.Scanner;

public class User
{
  String username;
  String password;
  
  public User()
  {
    this.username = "uPlaceholder";
    this.password = "pPlaceholder";
  }
  
  public String getUsername()
  {
    return this.username;
  }
  
  public String getPassword()
  {
    return this.password;
  }
  
  public void setUsername(String username)
  {
    this.username = username;
  }
  
  public void setPassword(String password)
  {
    this.password = password;
  }
  
  public void writeFile(String username, String password)
    throws IOException
  {
    File Users = new File(TheLibrary.instance.fileURL());
    FileWriter writer = new FileWriter(Users, true);
    writer.write(username.toLowerCase());
    writer.write("X");
    writer.write(password.toLowerCase());
    writer.write("X0\r\n");
    writer.flush();
    writer.close();
  }
  
  public static boolean removeUser(String username)
    throws IOException
  {
    File Users = new File(TheLibrary.instance.fileURL());
    Scanner sc = new Scanner(Users);
    String rewrite = "";
    String in = "";
    while (sc.hasNext())
    {
      String line = sc.nextLine();
      if (!line.split("X")[0].equals(username)) {
        rewrite = rewrite + line + "\r\n";
      } else System.out.print(username + " could not be remove, check that the user exists first");
      in = in + line + "\r\n";
    }
    sc.close();
    FileWriter writer = new FileWriter(Users);
    writer.write(rewrite);
    writer.flush();
    writer.close();
    return rewrite.length() != in.length();
  }
}
