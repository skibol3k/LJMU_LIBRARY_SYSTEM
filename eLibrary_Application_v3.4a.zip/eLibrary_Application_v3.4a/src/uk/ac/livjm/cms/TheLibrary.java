package uk.ac.livjm.cms;

import java.net.URL;
import java.util.LinkedList;
import java.util.List;

public class TheLibrary
{
  public List<Book> books;
  public static TheLibrary instance;
  
  public TheLibrary()
  {
    this.books = new LinkedList();
    instance = this;
  }
  
  public String fileURL()
  {
    return getClass().getResource("Users.txt").getPath().replace("%20", " ");
  }
  
  public String LibraryFileURL()
  {
    return getClass().getResource("Library.txt").getPath().replace("%20", " ");
  }
}
