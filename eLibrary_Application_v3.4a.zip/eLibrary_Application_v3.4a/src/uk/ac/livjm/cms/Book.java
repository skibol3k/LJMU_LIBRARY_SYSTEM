package uk.ac.livjm.cms;

import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.util.List;
import java.util.Scanner;

public class Book
{
  String author;
  String title;
  String link;
  
  public Book()
  {
    this.author = "aPlaceholder";
    this.title = "tPlaceholder";
    this.link = "lPlaceholder";
  }
  
  public Book(String pAuthor, String pTitle, String pLink)
  {
    this.author = pAuthor;
    this.title = pTitle;
    this.link = pLink;
  }
  
  public String getAuthor()
  {
    return this.author;
  }
  
  public String getLink()
  {
    return this.link;
  }
  
  public String getTitle()
  {
    return this.title;
  }
  
  public void setAuthor(String author)
  {
    this.author = author;
  }
  
  public void setTitle(String title)
  {
    this.title = title;
  }
  
  public void setLink(String link)
  {
    this.link = link;
  }
  
  public void writeFile(String author, String title, String link)
    throws IOException
  {
    File Books = new File(TheLibrary.instance.LibraryFileURL());
    
    FileWriter writer = new FileWriter(Books, true);
    writer.write(author);
    writer.write("::");
    writer.write(title);
    writer.write("::");
    writer.write(link + "\r\n");
    writer.flush();
    writer.close();
  }
  
  public boolean removeBook(String author, String title)
    throws IOException
  {
    File Library = new File(TheLibrary.instance.LibraryFileURL());
    Scanner sc = new Scanner(Library);
    int count = -1;
    String rewrite = "";
    String in = "";
    while (sc.hasNext())
    {
      count++;
      String line = sc.nextLine();
      in = in + line + "\r\n";
      String[] values = line.split("::");
      if ((!values[0].equals(author)) || (!values[1].equals(title))) {
        rewrite = rewrite + line + "\r\n";
      } else {
        TheLibrary.instance.books.remove(count);
      }
    }
    sc.close();
    FileWriter writer = new FileWriter(Library);
    writer.write(rewrite);
    writer.flush();
    writer.close();
    return in.length() != rewrite.length();
  }
}